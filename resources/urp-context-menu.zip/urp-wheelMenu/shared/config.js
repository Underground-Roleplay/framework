export const itemsList = [
    // usando png ou svg local ou web, sem texto
    {
        index: 'vehicle',
        items: [
            {
                title: 'Hide Radar',
                image: 'https://cdn.discordapp.com/attachments/771474161691394091/965767875266744360/belt.png',
                event: {
                    name: 'context:vehicle:trunk',
                    type: 'client',
                    params: '',
                },
            },
        ],
    },

    // usando https://fontawesome.com/icons/   \u{icon id}\n
    // texto + icone
    {
        index: 'personal',
        items: [
            {
                title: '\ue338\n',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
            {
                title: '\uf577\n personal',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
            {
                title: '\uf080\n personal',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
            {
                title: '\uf2c2\n personal',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
            {
                title: '\uf080\n personal',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
            {
                title: '\ue32e\n personal',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
            {
                title: '\uf080\n personal',
                event: { name: 'hideRadar', type: 'client', params: '' },
            },
        ],
    },
];
